from flask import Flask, render_template, request
import pandas as pd

app = Flask(__name__)

# CSV faylni o‘qish
df = pd.read_csv('data.csv')

# Har bir bosh so‘zning indexini aniqlash
word_indices = df[df.iloc[:, 0].notna()].index

@app.route('/', methods=['GET', 'POST'])
def index():
    word = ''
    block = pd.DataFrame()

    if request.method == 'POST':
        word = request.form.get('word', '').strip().lower()
        for i in range(len(word_indices)):
            idx = word_indices[i]
            cell_value = str(df.iloc[idx, 0]).lower()
            if cell_value == word:
                end_idx = word_indices[i + 1] if i + 1 < len(word_indices) else len(df)
                block = df.iloc[idx:end_idx].fillna('')
                break

    return render_template('index1.html', word=word, table=block.to_html(classes='styled-table', index=False, escape=False))

if __name__ == "__main__":
    app.run(debug=True)
